"""
Example 2
Write the output of the code below
"""

for i in range(5, 0, -1):
    print(i)
