"""
Example 7
Write the output of the code below
"""

def repeat_greet(name, times):
    for i in range(times):
        print("Hi", name)
        print(i)

repeat_greet("Leo", 3)
