"""
Example 4
Write the output of the code below
"""

def square(n):
    return n * n

print(square(2))
print(square(5))
