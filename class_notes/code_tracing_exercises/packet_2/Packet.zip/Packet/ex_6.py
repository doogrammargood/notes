"""
Example 6
Write the output of the code below
"""

def greet(name):
    print("Hello,", name)

greet("Sam")
greet("Ava")
