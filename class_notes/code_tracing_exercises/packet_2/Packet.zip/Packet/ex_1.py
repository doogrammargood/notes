"""
Example 1
Write the output of the code below
"""

for i in range(1, 6):
    print(i)